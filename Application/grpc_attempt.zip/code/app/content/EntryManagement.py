import datetime
import os
import cv2
from flask import Flask


import grpc

from app.area_pb2 import (CheckinHolder, CheckoutHolder)
from app.validation_pb2 import (CrownpassValidationRequest)
from app.area_pb2_grpc import EntryControlStub
from app.validation_pb2_grpc import ValidationStub

app = Flask(__name__)

area_host = os.getenv("AREA_HOST", "localhost")
api_channel = grpc.insecure_channel(
    f"{area_host}:50051"
)
api_client = EntryControlStub(api_channel)

validation_host = os.getenv("VALIDATION_HOST", "localhost")
api_channel2 = grpc.insecure_channel(
    f"{validation_host}:50053"
)
api_client2 = ValidationStub(api_channel2)

def check_in(areaID):#areaID, crownpassID):

    cap = cv2.VideoCapture(0)
    # initialize the cv2 QRCode detector

    detector = cv2.QRCodeDetector()

    while True:
        _, img = cap.read()
        data, bbox, tmp = detector.detectAndDecode(img)
        if data:
            print(f"QRCode data:\n{data}")
            break
    holder = CrownpassValidationRequest(
        id = str(data)
    )
    validation_response = api_client2.ValidateHolder(
        holder
    )
    if validation_response == 'Failed':
        return validation_response
    date = str(datetime.datetime.now().date())
    time = str(datetime.datetime.now().time())

    checkin_attempt = CheckinHolder(
        areaid=areaID,
        holderid=data,
        date = date,
        time = time
    )
    checkin_response = api_client.Checkin(
        checkin_attempt
    )
    return checkin_response

def check_out(areaID):
    cap = cv2.VideoCapture(0)
    # initialize the cv2 QRCode detector

    detector = cv2.QRCodeDetector()
    data = 1234567890
    while True:
        _, img = cap.read()
        data, bbox, tmp = detector.detectAndDecode(img)
        if data:
            print(f"QRCode data:\n{data}")
            break
    holder = CrownpassValidationRequest(
        id=str(data)
    )
    validation_response = api_client2.ValidateHolder(
        holder
    )
    if validation_response == 'Failed':
        return validation_response
    date = str(datetime.datetime.now().date())
    time = str(datetime.datetime.now().time())

    checkout_attempt = CheckoutHolder(
        areaid=areaID,
        holderid=data,
        date=date,
        time=time
    )

    checkout_response = api_client.Checkout(
        checkout_attempt
    )
    return checkout_response
    #AreaID, CrownpassID, EntryDate, EntryTime, ExitDate, ExitTime