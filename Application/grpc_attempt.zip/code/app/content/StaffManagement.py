import json
import os

from flask import Flask

#AreaID, StaffID, Username, Password
#from api.user_registration import *
import grpc

from app.validation_pb2 import (StaffValidationRequest)
from app.validation_pb2_grpc import ValidationStub
from app.registration_pb2 import (Staff, StaffRegistrationRequest)
from app.registration_pb2_grpc import RegistrationStub

app = Flask(__name__)

registration_host = os.getenv("REGISTRATION_HOST", "localhost")
api_channel = grpc.insecure_channel(
    f"{registration_host}:50052"
)
api_client = RegistrationStub(api_channel)
validation_host = os.getenv("VALIDATION_HOST", "localhost")
api_channel2 = grpc.insecure_channel(
    f"{validation_host}:50053"
)
api_client2 = ValidationStub(api_channel2)


class StaffAccount:
    def __init__(self):
        self.areaID = ''
        self.staffID = ''
        self.username = ''
        self.password = ''

    def register(self, staff_details, area_id):
        self.areaID = str(area_id)
        self.staffID = str(uuid4())
        self.username = staff_details['username']
        self.password = staff_details['password']
        new_staff = Staff(
            _id = self.staffID,
            areaid = self.areaID,
            UserName = self.username,
            Password = self.password
        )
        register_staff = StaffRegistrationRequest(
            staff = new_staff
        )
        register_response = api_client.RegisterStaff(
            register_staff
        )
        return register_response

    def login(self, user, passw):
        staff_val = StaffValidationRequest(
            username = user,
            password = passw
        )
        validation_response = api_client2.ValidateStaff(
            staff_val
        )
        if isinstance(validation_response, str):
            return validation_response
        else:
            self.areaID = validation_response['_id']
            self.staffID = validation_response['areaid']
            self.username = validation_response['UserName']
            self.password = validation_response['Password']
            return self