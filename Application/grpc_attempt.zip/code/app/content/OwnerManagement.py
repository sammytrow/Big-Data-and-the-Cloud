import os
from uuid import uuid4

from flask import Flask

#AreaID, Password, AreaName, userName, Postcode, County, City, Street, No., EntryLvl
import grpc

from app.validation_pb2 import (AreaValidationRequest)
from app.validation_pb2_grpc import ValidationStub
from app.registration_pb2 import (Area, AreaRegistrationRequest)
from app.registration_pb2_grpc import RegistrationStub

app = Flask(__name__)

registration_host = os.getenv("REGISTRATION_HOST", "localhost")
api_channel = grpc.insecure_channel(
    f"{registration_host}:50052"
)
api_client = RegistrationStub(api_channel)

validation_host = os.getenv("VALIDATION_HOST", "localhost")
api_channel2 = grpc.insecure_channel(
    f"{validation_host}:50053"
)
api_client2 = ValidationStub(api_channel2)

class AreaAccount:
    def __init__(self):
        self.areaID = ''
        self.password = ''
        self.areaName = ''
        self.userName = ''
        self.postcode = ''
        self.county = ''
        self.city = ''
        self.street = ''
        self.areaNum = ''
        self.entryLvl = ''
        self.staff = []
        self.currentNum = ''
        self.maxNum = ''


    def register(self, area_details):
        self.areaID = str(uuid4())
        self.password = area_details['password']
        self.areaName = area_details['areaName']
        self.userName = area_details['username']
        self.postcode = area_details['postcode']
        self.county = area_details['county']
        self.city = area_details['city']
        self.street = area_details['street']
        self.areaNum = area_details['areaNum']
        self.entryLvl = area_details['entryLvl']
        self.currentNum = '0'
        self.maxNum = area_details['maxNum']
        #jsonStr = json.dumps(self.__dict__)
        new_area = Area(
            _id = self.areaID,
            Password = self.password,
            AreaName = self.areaName,
            UserName = self.userName,
            Postcode = self.postcode,
            County = self.county,
            City = self.city,
            Street = self.street,
            Num = self.areaNum,
            EntryLvl = self.entryLvl,
            CurrentNum = self.currentNum,
            MaxNum = self.maxNum
        )
        register_area = AreaRegistrationRequest(
            area=new_area
        )
        register_response = api_client.RegisterArea(
            register_area
        )
        return register_response

    def login(self, user, area_passw):
        area_val = AreaValidationRequest(
            username=user,
            password=area_passw
        )
        validation_response = api_client2.ValidateArea(
            area_val
        )

        if isinstance(validation_response, str):
            return validation_response
        else:
            self.areaID = validation_response['_id']
            self.password = validation_response['Password']
            self.areaName = validation_response['AreaName']
            self.userName = validation_response['UserName']
            self.postcode = validation_response['Postcode']
            self.county = validation_response['County']
            self.city = validation_response['City']
            self.street = validation_response['Street']
            self.areaNum = validation_response['Num']
            self.entryLvl = validation_response['EntryLvl']
            self.currentNum = validation_response['CurrentNum']
            self.maxNum = validation_response['MaxNum']
            return self


    def get_staff(self):
        pass

    def get_customers(self):
        pass