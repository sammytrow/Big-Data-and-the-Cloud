'''
def example_registration():
    area = AreaAccount()
    result = area.register(area_example)
    print(result)
    return area


def example_login():
    area = AreaAccount()
    result = area.login(area_example["username"], area_example["password"])
    print(result)

def example_staff_reg(area):
    new_staff = StaffAccount()
    result = new_staff.register(staff_example, area.areaID)
    print(result)
    return new_staff

def example_staff_login():
    staff = StaffAccount()
    result = staff.login(staff_example["username"], staff_example["password"])
    print(result)

def example_checkin():
    response = check_in("07c51711-777d-48d4-a240-94c227bf2e49")
    print(response)
    response = check_in("c92ce37c-650e-479d-b94f-c9d86cfb198c")
    print(response)

def example_checkout():
    response = check_out("c92ce37c-650e-479d-b94f-c9d86cfb198c")
    print(response)'''