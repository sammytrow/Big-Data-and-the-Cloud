from concurrent import futures
from uuid import uuid4

import grpc
from pymongo import MongoClient
from area_pb2 import(EntryResponse)
import area_pb2_grpc

def connect():
    conn_str = 'mongodb+srv://big-data:database5@cluster0.tfurl.mongodb.net/'
    client = MongoClient(conn_str)
    return client

class EntryControlService(area_pb2_grpc.EntryControl):
    def check_in_crownpass(self, areaid, holderid, date,time):
        client = connect()

        db = client.get_database("Area_Database")
        collection = db.Areas

        x = collection.find({"_id": areaid})

        for doc in x:
            if doc['MaxNum'] != doc['CurrentNum']:
                ans = meet_requirements(holderid, doc['EntryLvl'])
                if not ans:
                    return "Does not meet requirements"
                newNum = int(doc['CurrentNum']) + 1
                collection.update_one({"_id": areaid}, {"$set": { "CurrentNum" : str(newNum)}})
                x = collection.find({"_id": areaid})
                for doc in x:
                    print(doc)
            else:
                return EntryResponse("Too many Customers")

        db = client.get_database("Area_Entry_Database")
        collection = db["Area Entry"]
        entry_id = str(uuid4())
        entry = {
            "_id" : entry_id,
            "Areaid" : areaid,
            "Holderid" : holderid,
            "EntryDate" : str(date),
            "EntryTime" : str(time),
            "ExitDate" : "",
            "ExitTime" : "",
        }
        collection.insert_one(entry)
        x = collection.find({"_id": str(entry_id)})
        for doc in x:
            return EntryResponse("Check in complete")
        return EntryResponse("Error")

    def check_out_crownpass(self, areaid, holderid, date, time):
        client = connect()

        db = client.get_database("Area_Entry_Database")
        collection = db["Area Entry"]

        collection.update_one({"Areaid" : areaid, "Holderid": holderid}, {"$set" : {"ExitDate" : str(date), "ExitTime" : str(time)}})

        x = collection.find({"_id": str(holderid)})
        for doc in x:
            print(doc)

        db = client.get_database("Area_Database")
        collection = db.Areas

        x = collection.find({"_id": areaid})
        for doc in x:
            newNum = int(doc['CurrentNum']) - 1
            collection.update_one({"_id": areaid}, {"$set": {"CurrentNum": str(newNum)}})
            return EntryResponse("Check out complete")
        return EntryResponse("Unknown Error")


    def meet_requirements(self, id, lvl):
        client = connect()

        db = client.get_database("Crownpass_Holder")
        collection = db.Crownpass_Holder

        x = collection.find({"_id": id})
        for doc in x:
            if doc['infection'] >= lvl:
                return True
        return False

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    area_pb2_grpc.add_EntryControlServicer_to_server(
        EntryControlService(), server
    )
    server.add_insecure_port("[::]:50051")
    server.start()
    server.wait_for_termination()


if __name__ == "__main__":
    serve()