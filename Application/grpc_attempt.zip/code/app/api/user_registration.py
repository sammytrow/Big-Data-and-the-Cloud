import json
from concurrent import futures

import grpc
from pymongo import MongoClient
from registration_pb2 import(RegistrationResponse)
import registration_pb2_grpc

def connect():
    conn_str = 'mongodb+srv://big-data:database5@cluster0.tfurl.mongodb.net/'
    client = MongoClient(conn_str)
    return client

class RegistrationService(registration_pb2_grpc.Registration):
    def register_area(self, area):
        client = connect()
        db = client.get_database("Area_Database")
        collection = db.Areas
        already_exists = False
        #check username also location and name details to ensure they arent already used
        area = json.loads(area)
        x = collection.find({"Postcode": area["postcode"],
            "County": area["county"],
            "City": area["city"],
            "Street": area["street"],
            "Num": area["areaNum"],})
        for doc in x:
            return RegistrationResponse("This area is already registered")

        x = collection.find({"UserName": area["userName"]})
        for doc in x:
            return RegistrationResponse("Username exists")

        new_area = {
            "_id": str(area["areaID"]),
            "Password": area["password"],
            "AreaName": area["areaName"],
            "UserName": area["userName"],
            "Postcode": area["postcode"],
            "County": area["county"],
            "City": area["city"],
            "Street": area["street"],
            "Num": area["areaNum"],
            "EntryLvl": area["entryLvl"],
            "CurrentNum": area["currentNum"],
            "MaxNum": area["maxNum"]
        }

        collection.insert_one(new_area)
        x = collection.find({"_id":str(area["areaID"])})

        for doc in x:
            return RegistrationResponse("Registration Complete")
        return RegistrationResponse("Unknown Error")

    def register_staff(self, staff):
        client = connect()
        db = client.get_database("Staff_Database")
        collection = db.Staff

        staff = json.loads(staff)
        # check username doesnt exist for area
        x = collection.find({"UserName" : staff["username"]})
        for doc in x:
            return RegistrationResponse("Username exists")

        new_staff = {
            "_id": str(staff["staffID"]),
            "areaid": str(staff["areaID"]),
            "UserName": staff["username"],
            "Password": staff["password"]
        }

        collection.insert_one(new_staff)
        x = collection.find({"_id": str(staff["staffID"])})

        for doc in x:
            return RegistrationResponse("Registration Complete")
        return RegistrationResponse("Unknown Error")

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    registration_pb2_grpc.add_RegistrationServicer_to_server(
        RegistrationService(), server
    )
    server.add_insecure_port("[::]:50052")
    server.start()
    server.wait_for_termination()


if __name__ == "__main__":
    serve()