from concurrent import futures

from pymongo import MongoClient
import grpc

from validation_pb2 import(CrownpassValidationResponse, AreaValidationResponse, StaffValidationResponse)
import validation_pb2_grpc
def connect():
    conn_str = 'mongodb+srv://big-data:database5@cluster0.tfurl.mongodb.net/'
    client = MongoClient(conn_str)

    return client

class ValidationService(validation_pb2_grpc.Validation):
    def validate_holder(self, id):
        client = connect()

        db = client.get_database("Crownpass_Holder")
        collection = db.Crownpass_Holder

        x = collection.find({"_id":1234567890})

        for result in x:
            return CrownpassValidationResponse("Success")
        return CrownpassValidationResponse("Failed")

    def validate_area(self, username, password):
        client = connect()

        db = client.get_database("Area_Database")
        collection = db.Areas

        x = collection.find({"UserName": username, "Password": password})

        for result in x:
            return AreaValidationResponse(result)
        return AreaValidationResponse("Failed")

    def validate_staff(self, username, password):
        client = connect()

        db = client.get_database("Staff_Database")
        collection = db.Staff

        x = collection.find({"UserName": username, "Password": password})

        for result in x:
            return StaffValidationResponse(result)
        return StaffValidationResponse("Failed")

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    validation_pb2_grpc.add_ValidationServicer_to_server(
        ValidationService(), server
    )
    server.add_insecure_port("[::]:50053")
    server.start()
    server.wait_for_termination()


if __name__ == "__main__":
    serve()